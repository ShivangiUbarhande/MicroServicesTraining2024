package com.controller;

import com.entity.Product;
import com.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RefreshScope
@RequestMapping("/products")
public class ProductController {

    @Value("${spring.appname}")
    String appName;

    @Autowired
    private ProductService service;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product) {
        return service.addProduct(product);
    }

//    @DeleteMapping("/deleteProduct")
//    public void deleteProduct(@RequestBody Product product) {
//        service.deleteProduct(product);
//    }

    @GetMapping("/getAllProducts")
    public List<Product> getAllProducts() {
        System.out.println("AppName: " + appName);
        return service.getAllProducts();
    }

    @GetMapping("/getAllProducts/{idList}")
    public List<Product> getProductsByIds(@PathVariable List<Long> idList) {
        return service.getProductsByIds(idList);
    }
}

package com.service;

import com.entity.Product;
import com.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepo productRepo;

    public Product addProduct(Product product) {
        return productRepo.save(product);
    }

//    public void deleteProduct(Product product) {
//         productRepo.delete(product);
//    }

    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    public List<Product> getProductsByIds(List<Long> ids) {
        return productRepo.findAllById(ids);
    }
}

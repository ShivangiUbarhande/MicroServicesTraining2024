package com.security.spring_security;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RestAppSecurity {

    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";
    }
    @GetMapping("/home")
    public String home() {
        return "home";
    }
    @GetMapping("/admin")
    public String admin() {
        return "admin";
    }
    @GetMapping("/qa")
    public String qa() {
        return "qa";
    }
    @GetMapping("/superadmin")
    public String superadmin() {
        return "superadmin";
    }
    @GetMapping("/employee")
    public String employee() {
        return "employee";
    }
    @GetMapping("/manager")
    public String manager() {
        return "manager";
    }
    @GetMapping("/common")
    public String common() {
        return "common";
    }

    @GetMapping("/accessdenied")
    public String accessdenied() {
        return "accessdenied";
    }
}

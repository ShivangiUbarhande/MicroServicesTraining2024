package com.service;

import com.entity.CartEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Product;
import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;
import com.repository.CartRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartService {
    @Autowired
    @Qualifier("webClient")
    private WebClient.Builder builder;

    @Autowired
    private CartRepo repo;

    public ShoppingCartResponse processAndSend(Long userId,  List<ShoppingCartRequest> shoppingCartRequests) {
        ObjectMapper mapper= new ObjectMapper();
        String productServiceURL="http://localhost:8090/products/getAllProducts/"+shoppingCartRequests.stream()
                .map(e -> String.valueOf(e.getProductId())).collect(Collectors.joining(","));
        List<Product> productServiceList=builder.build()
                .get()
                .uri(productServiceURL)
                .retrieve()
                .bodyToFlux(Product.class)
                .collectList()
                .block();
        Double [] totalConsts= {0.0};
        productServiceList.forEach(psl -> {
            shoppingCartRequests.forEach(cr -> {
                if(psl.getId() == cr.getProductId()) {
                    psl.setQuantity(cr.getQuantity());
                    totalConsts[0]= totalConsts[0]+psl.getAmount()*cr.getQuantity();
                }
            });
        });
        CartEntity cartEntity=null;
        try {
            cartEntity=CartEntity.builder()
                    .userId(userId)
                    .cartId((long)(Math.random()*Math.pow(10, 10)))
                    .totalItems(productServiceList.size())
                    .totalPrice(totalConsts[0])
                    .products(mapper.writeValueAsString(productServiceList))
                    .build();
            cartEntity=repo.save(cartEntity);
        }catch (Exception e) {

        }
        //return response
        ShoppingCartResponse res= ShoppingCartResponse.builder()
                .cartId(cartEntity.getCartId())
                .userId(cartEntity.getUserId())
                .totalItems(cartEntity.getTotalItems())
                .totalPrice(cartEntity.getTotalPrice())
                .ProductList(productServiceList)
                .build();
        return res;

    }
}

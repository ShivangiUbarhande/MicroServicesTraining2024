package com.controller;

import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;
import com.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shoppingCart")
public class ShoppingCart {
    @Autowired
    private CartService service;
    @PostMapping("/{userid}/products")
    public ResponseEntity addProductToCart(@PathVariable Long userid, @RequestBody List<ShoppingCartRequest> reqData) {
        ShoppingCartResponse response= service.processAndSend(userid, reqData);
        return new ResponseEntity(response, HttpStatus.CREATED);
    }
}
